export const products = [
  {
    id: 1,
    name: "CBD Oil 1000mg",
    price: 49.99,
    description: "Premium full-spectrum CBD oil\nStrength: 1000mg\nSize: 30ml",
    category: "oils"
  },
  {
    id: 2,
    name: "CBD Gummies",
    price: 29.99,
    description: "Organic CBD gummies\nStrength: 25mg per gummy\n30 pieces",
    category: "edibles"
  },
  {
    id: 3,
    name: "CBD Cream",
    price: 39.99,
    description: "Topical CBD cream\nStrength: 500mg\nSize: 50ml",
    category: "topicals"
  }
];